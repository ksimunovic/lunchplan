#!/bin/bash
while ! wget --spider mongodb:27017
do
  echo "$(date) - still trying"
  sleep 1
done
mongoimport --host mongodb --db UserService --collection account --type json --file /account.json 
mongoimport --host mongodb --db UserService --collection profile --type json --file /profile.json 
mongoimport --host mongodb --db UserService --collection session --type json --file /session.json 
mongoimport --host mongodb --db MealService --collection meal --type json --file /meal.json 
mongoimport --host mongodb --db TagService --collection tag --type json --file /tag.json 
mongoimport --host mongodb --db CalendarService --collection calendar --type json --file /calendar.json 
mongo --host mongodb < adminuser.js